package com.pixelplatformer.framework;

public enum ObjectId {

    Player(), Block(), Flag();

}
